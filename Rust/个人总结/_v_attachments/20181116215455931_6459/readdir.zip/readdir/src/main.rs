use std::env;
use std::fs;

extern crate chrono;
use chrono::prelude::*;

fn main() {
    if let Ok(dir) = env::current_dir() {
        let base = dir.to_str().unwrap();
        println!("目录: {:<35}", base);
        read_dir(base, 1);
    }
}

fn read_dir(base: &str, level: usize) {
    let obj = fs::read_dir(base).expect("启动目录读取失败");

    obj.for_each(|item| {
        if let Ok(entry) = item {

	        let item = if entry.file_type().unwrap().is_dir() {
                "短名"
            } else {
                "目录"
            };

            let meta = entry.metadata().unwrap();
            let c: DateTime<Local> = chrono::DateTime::from(meta.created().unwrap());
            let m: DateTime<Local> = chrono::DateTime::from(meta.modified().unwrap());

            println!(
                "{:>width$}: {:<30} 创建时间: {:<25} 修改时间: {:<25}",
                item,
                entry.file_name().to_str().unwrap(),
                c.format("%F %T%.3f"),
                m.format("%F %T%.3f"),
                width = level * 4,
            );

            if meta.is_dir() {
                read_dir(entry.path().to_str().unwrap(), level + 1);
            }
        }
    });
}
