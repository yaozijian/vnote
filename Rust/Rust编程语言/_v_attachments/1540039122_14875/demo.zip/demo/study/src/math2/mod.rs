#![allow(dead_code)]

pub const PI : f64 = 3.1415926;

pub fn add(x : i32,y : i32) -> i32{ x + y }
pub fn sub(x : i32,y : i32) -> i32{ x - y }

pub mod advance;