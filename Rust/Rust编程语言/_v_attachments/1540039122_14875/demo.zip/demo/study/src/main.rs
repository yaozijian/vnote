
mod math;
mod math2;
extern crate math3;

fn main() {
    assert_eq!(math::add(1,2),3);
    assert_eq!(math::advance::square(2),4);

    assert_eq!(math2::add(1,2),3);
    assert_eq!(math2::advance::square(2),4);

    assert_eq!(math3::add(1,2),3);
    assert_eq!(math3::advance::square(2),4);
}
