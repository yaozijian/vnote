pub fn sub_two(a: i32, b: i32) -> i32 {
	a - b
}