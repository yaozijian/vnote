
#![feature(fnbox,generators,generator_trait)]
#![allow(unused_must_use)]

use mio::*;
use mio::net::{TcpListener,TcpStream};
use std::io::{Read,Write,self};
use failure::Error;
use std::time::{Duration,Instant};

const TOKEN_LISTEN_SOCKET : Token = Token(0);
const TOKEN_SERVE_SOCKET : Token = Token(1);
const TOKEN_CLIENT_SOCKET: Token = Token(2);
const MSG_PING : &[u8] = b"Ping";
const MSG_PONG : &[u8] = b"Pong";

mod asyncop;
mod callback;
mod event;
mod coroutine_1;

fn main() -> Result<(),Error>{

    callback::main();
    event::main();
    coroutine_1::main();

	let console = asyncop::Fs::new();

	let addr = "127.0.0.1:13265".parse()?;
	let listener = TcpListener::bind(&addr)?;

	let poll = Poll::new()?;
	poll.register(&listener,TOKEN_LISTEN_SOCKET,Ready::readable(),PollOpt::edge());

	let mut client_socket = TcpStream::connect(&addr)?;
	poll.register(&client_socket,TOKEN_CLIENT_SOCKET,Ready::readable() | Ready::writable(),PollOpt::edge());

	let mut serve_socket = None;

	let mut events = Events::with_capacity(1024);
	let start = Instant::now();
	let timeout = Duration::from_millis(10);

	'top: loop{

		if start.elapsed() >= timeout{
			break 'top;
		}

		poll.poll(&mut events,None)?;

		for event in events.iter(){
			match event.token(){
				TOKEN_LISTEN_SOCKET => {
					let (socket,addr) = listener.accept()?;
					console.println(format!("接受客户端连接: {}",&addr));
					poll.register(&socket,TOKEN_SERVE_SOCKET,Ready::readable(),PollOpt::edge());
					serve_socket = Some(socket);
				},
				TOKEN_SERVE_SOCKET => {
					if event.readiness().is_readable() {
						let mut hello = [0;4];
						if let Some(ref mut handler) = &mut serve_socket{
							match handler.read_exact(&mut hello){
								Ok(_) => {

									assert_eq!(MSG_PING,&hello);
									console.println(format!("服务器收到Ping"));

									match handler.write(MSG_PONG){
										Ok(_) => console.println(format!("服务器发送Pong完成")),
										Err(ref err) if err.kind() == io::ErrorKind::WouldBlock => continue,
										err => {err?;}
									}
								}
								Err(ref err) if err.kind() == io::ErrorKind::WouldBlock => continue,
								err => err?
							}
						}
					}
				},
				TOKEN_CLIENT_SOCKET => {
					if event.readiness().is_readable() {
						let mut hello = [0; 4];
						match client_socket.read_exact(&mut hello) {
							Ok(_) => {
								assert_eq!(MSG_PONG, &hello);
								console.println(format!("客户端收到Pong\n"));
							}
							Err(ref err) if err.kind() == io::ErrorKind::WouldBlock => continue,
							err =>{ err?;}
						}
					}
					if event.readiness().is_writable(){
						match client_socket.write(MSG_PING) {
							Ok(_) => console.println(format!("客户端发送Ping完成")),
							Err(ref err) if err.kind() == io::ErrorKind::WouldBlock => continue,
							err => {err?;}
						}
					}
				},
				_ => unreachable!()
			}
		}
	}
    Ok(())
}