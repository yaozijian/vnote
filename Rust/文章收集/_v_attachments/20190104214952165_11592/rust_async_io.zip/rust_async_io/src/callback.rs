use crossbeam_channel::{unbounded, Sender};
use failure::Error;
use std::boxed::FnBox;
use std::fs::File;
use std::io::Read;
use std::thread;

// 定义回调函数类型: 需要使用Box,因为函数是大小不确定类型
type FileCallback = Box<FnBox(Fs, File) -> Result<(), Error> + Sync + Send + 'static>;
type StringCallback = Box<FnBox(Fs, String) -> Result<(), Error> + Sync + Send + 'static>;

pub enum Task {
    Exit,
    Println(String),
    Open(FileCallback, Fs, String),
    ReadToString(StringCallback, Fs, File),
}

pub enum TaskResult {
    Exit,
    Open(FileCallback, Fs, File),
    ReadToString(StringCallback, Fs, String),
}

#[derive(Clone)]
pub struct Fs {
    task_sender: Sender<Task>,
}

pub struct FsHandler {
    io_worker: thread::JoinHandle<Result<(), Error>>,
    executor: thread::JoinHandle<Result<(), Error>>,
}

// 转发请求到通道中,对需要返回值的请求,需要给定回调函数
impl Fs {
    pub fn println(&self, string: String) -> Result<(), Error> {
        Ok(self.task_sender.send(Task::Println(string))?)
    }

    pub fn open<F>(&self, path: &str, callback: F) -> Result<(), Error>
    where
        F: FnOnce(Fs, File) -> Result<(), Error> + Sync + Send + 'static,
    {
        Ok(self.task_sender.send(Task::Open(
            Box::new(callback),
            self.clone(),
            path.to_string(),
        ))?)
    }

    pub fn read_to_string<F>(&self, file: File, callback: F) -> Result<(), Error>
    where
        F: FnOnce(Fs, String) -> Result<(), Error> + Sync + Send + 'static,
    {
        Ok(self
            .task_sender
            .send(Task::ReadToString(Box::new(callback), self.clone(), file))?)
    }

    pub fn close(&self) -> Result<(), Error> {
        Ok(self.task_sender.send(Task::Exit)?)
    }
}

impl FsHandler {
    pub fn join(self) -> Result<(), Error> {
        self.io_worker.join().unwrap()?;
        self.executor.join().unwrap()
    }
}

pub fn fs_async() -> (Fs, FsHandler) {
    let (task_sender, task_receiver) = unbounded();
    let (result_sender, result_receiver) = unbounded();

    // 接收并处理请求线程
    let io_worker = std::thread::spawn(move || {
        loop {
            match task_receiver.recv() {
                Ok(task) => {
                    match task {
                        Task::Println(ref string) => println!("{}", string), // 简单任务直接处理
                        Task::Open(callback, fs, path) => {
                            // 复杂任务需要将执行结果返回到执行线程
                            result_sender.send(TaskResult::Open(callback, fs, File::open(path)?))?
                        }
                        Task::ReadToString(callback, fs, mut file) => {
                            let mut value = String::new();
                            file.read_to_string(&mut value)?;
                            result_sender.send(TaskResult::ReadToString(callback, fs, value))?
                        }
                        Task::Exit => {
                            result_sender.send(TaskResult::Exit)?;
                            break;
                        }
                    }
                }
                Err(_) => {
                    break;
                }
            }
        }
        Ok(())
    });

    let executor = std::thread::spawn(move || {
        loop {
            // 执行线程负责调用回调函数
            let result = result_receiver.recv()?;
            match result {
                TaskResult::ReadToString(callback, fs, value) => callback.call_box((fs, value))?,
                TaskResult::Open(callback, fs, file) => callback.call_box((fs, file))?,
                TaskResult::Exit => break,
            };
        }
        Ok(())
    });

    (
        Fs { task_sender },
        FsHandler {
            io_worker,
            executor,
        },
    )
}

const TEST_FILE_VALUE: &str = "Hello, World!";

pub fn main() -> Result<(), Error> {
    let (fs, fs_handler) = fs_async();
    fs.open("./examples/test.txt", |fs, file| {
        fs.read_to_string(file, |fs, value| {
            assert_eq!(TEST_FILE_VALUE, &value);
            fs.println(value)?;
            fs.close()
        })
    })?;
    fs_handler.join()?;
    Ok(())
}
