use std::ops::{Generator, GeneratorState};
use std::borrow::{BorrowMut};

pub fn main() {
    let mut gen = fab(5);
    loop {
        match unsafe { gen.resume() } {
            GeneratorState::Yielded(value) => println!("下一个值: {}", value),
            GeneratorState::Complete(ret) => {
                println!("返回值: {}", ret);
                break;
            }
        }
    }
}

fn fab(mut n: u64) -> impl Generator<Yield = u64, Return = u64> {
    move || {
        let mut last = 0u64;
        let mut current = 1u64;
        while n > 0 {
            yield current;
            let tmp = current;
            current += last;
            last = tmp;
            n -= 1;
        }
        return current;
    }
}

fn self_ref_generator() -> impl Generator<Yield=u64, Return=()> {
    || {
        let x: u64 = 1;
        let ref_x: &u64 = &x;
        yield *ref_x;
        yield 0;
    }
}

struct A<'a> {
    b: u64,
    ref_b: Option<&'a u64>
}

impl<'a> A<'a> {
    fn new() -> Self { A{b: 1, ref_b: None}}
    fn mute(&mut self) {}
}

fn main2() {
    let mut a = A::new();
    a.ref_b = Some(&a.b);
    //a.mute();// 编译通不过: 已经有对a的不可变借用,不能再进行可变借用了
}
