#![feature(futures_api, async_await, await_macro)]
#![feature(arbitrary_self_types)]

use futures::executor::block_on;
use futures::join;

struct Song {
    name: String,
}

async fn learn_song() -> Song {
    println!("学习唱歌");
    Song {
        name: String::from("我和我的祖国"),
    }
}

async fn sing_song(song: Song) {
    println!("唱歌: {}", song.name)
}

async fn dance() {
    println!("跳舞")
}

async fn learn_and_sing() {
    // 在唱歌之前等待学歌完成
    // 这里我们使用 `await!` 而不是 `block_on` 来防止阻塞线程，这样就可以同时执行 `dance` 了。
    let song = await!(learn_song());
    await!(sing_song(song));
}

async fn async_main() {
    let f1 = learn_and_sing();
    let f2 = dance();
    // `join!` 类似于 `await!` ，但是可以等待多个 future 并发完成
    join!(f1, f2);
}

mod timer;

fn main() {
    block_on(async_main());
    timer::main();
}
